#include <xc.h>
#include <stdint.h>
#include "I2C.h"
char Tempr[] = " 00.0 C"; //set Temp display format in kelvin
char S_Tempr[] = " 00.0 C"; //set Sevaed Temp display format in kelvin
int C, SD;    
//--[ Functinos Definitions ]--
void EEPROM_Write(uint8_t Address, uint8_t Data)
{
  while(EECON1bits.WR); // Waits Until Last Attempt To Write Is Finished
  EEADR = Address;      // Writes The Addres To Which We'll Wite Our Data
  EEDATA = Data;        // Write The Data To Be Saved
  EECON1bits.EEPGD = 0; // Cleared To Point To EEPROM Not The Program Memory
  EECON1bits.WREN = 1;  // Enable The Operation !
  INTCONbits.GIE = 0;   // Disable All Interrupts Untill Writting Data Is Done
  EECON2 = 0x55;        // Part Of Writing Mechanism..
  EECON2 = 0xAA;        // Part Of Writing Mechanism..
  EECON1bits.WR = 1;    // Part Of Writing Mechanism..
  INTCONbits.GIE = 1;   // Re-Enable Interrupts
  EECON1bits.WREN = 0;  // Disable The Operation
  EECON1bits.WR = 0;    // Ready For Next Writting Operation
}
uint8_t EEPROM_Read(uint8_t Address)
{
  uint8_t Data;
  EEADR = Address;      // Write The Address From Which We Wonna Get Data
  EECON1bits.EEPGD = 0; // Cleared To Point To EEPROM Not The Program Memory
  EECON1bits.RD = 1;    // Start The Read Operation
  Data = EEDATA;        // Read The Data
  return Data; 
}
void ADC_Init()
{
TRISA = 0xff; //*set as input port*/ 
ADCON1 = 0b11110000; //Right Justify, FRC Clock , All pins as Analog Input and setting Reference Voltages 
ADCON0 = 0b00000001; //Turn ON ADC and Clock Selection
ADRESH = 0; //*Flush ADC output Register*/
ADRESL = 0;
}
unsigned int ADC_Read(unsigned char channel)
{

 ADCON0 |= channel<< 1; //Setting the required Bits
  __delay_ms(2); //Acquisition time to charge hold capacitor
  GO_nDONE = 1; //Initializes A/D Conversion
  while(GO_nDONE); //Wait for A/D Conversion to complete
  return ((ADRESH<< 8)+ADRESL); //Returns Result
}


void main()
{
   
    I2C__Init();
    LCD_Init(0x4E);    // Initialize LCD module with I2C address = 0x4E
    LCD_Set_Cursor(1,1);
    LCD_Write_String(" MicroDigisoft ");
    LCD_Set_Cursor(2,1);
    LCD_Write_String("EEPROM Project");
    __delay_ms(10);
    LCD_Clear();
    TRISD = 0x00; //PORTD declared as output for interfacing LCD
    TRISA4 =1; //AN4 declared as input
    TRISB0  = 1;
    OPTION_REG=0b00000000;
    ADC_Init();
    LCD_Clear();    
    while(1)
    { 
    C = ADC_Read(0) * 0.489;               // // Read analog voltage and convert it to degree Celsius (0.489 = 500/1023)
    if (C > 99)
      Tempr[0]  = 1 + 48;              // Put 1 (of hundred)
    else
        //**Display ADC**//
    Tempr[0]  = ' ';                 // Put space
    Tempr[1]  = (C / 10) % 10  + 48;
    Tempr[2]  =  C % 10  + 48;
    Tempr[5] = 223;                    // Put degree symbol ( � )
    
    
    //Saved ADC format
    if (SD > 99)
      S_Tempr[0]  = 1 + 48;              // Put 1 (of hundred)
    else
        //**Display ADC**//
    S_Tempr[0]  = ' ';                 // Put space
    S_Tempr[1]  = (SD / 10) % 10  + 48;
    S_Tempr[2]  =  SD % 10  + 48;
    S_Tempr[5] = 223;                    // Put degree symbol ( � )
    
    
        
        LCD_Set_Cursor(1,1);
        LCD_Write_String("TEMP:");
        LCD_Write_String(Tempr);
        
        
      //**Display SADC**//
     
        LCD_Set_Cursor(2,1);
        LCD_Write_String("Saved TEMP:");
        LCD_Write_String(S_Tempr);
             /*These devices have 4 or 8K words of
          program Flash, with an address range from 0000h to
          1FFFh for the PIC16F877A*/
        
        if (RB0==0)
        {EEPROM_Write(0,C);}
        __delay_ms(50);
   
        SD= (int)EEPROM_Read(0);
        __delay_ms(50);
        LCD_Set_Cursor(1,1);
        LCD_Write_String("TEMP:");
        LCD_Write_String(Tempr);
        
    }
  
}   
    
    
